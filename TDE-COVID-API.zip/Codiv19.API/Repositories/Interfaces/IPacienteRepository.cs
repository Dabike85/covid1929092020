﻿using Codiv19.API.Models;
using Codiv19.API.Repositories.Interfaces.Base;

namespace Codiv19.API.Repositories.Interfaces
{
    public interface IPacienteRepository : IRepositoryBase<Paciente>
    {
    }
}
