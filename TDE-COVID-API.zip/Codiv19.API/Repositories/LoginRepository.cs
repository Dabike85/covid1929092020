﻿using Codiv19.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;

namespace Codiv19.API.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        public Login GetLogin(Login login)
        {
            if (login.usuario == "Hugo" && login.senha == "123456")
            {
                login.id = 1;
                login.grupo = "adm";
                return login;
            }
            return null;
        }
        
    }
}
