﻿using Codiv19.API.Models;
using Codiv19.API.Services.Interfaces.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Codiv19.API.Services.Interfaces
{
    public interface IPacienteService : IServiceBase<Paciente>
    {
    }
}
